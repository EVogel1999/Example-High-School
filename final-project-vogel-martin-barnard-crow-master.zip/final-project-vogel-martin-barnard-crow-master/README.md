# Group Members
Toye Bernard, Cameron Crow, Mary Martin, Emily Vogel


# Link to Deployed Application
https://example-high-school.firebaseapp.com/


# How to run Locally

1. Clone this repository, master branch specifically.  Running on the deploy branch will not work as it is set up to the deployed sites for front and backend.

2. Navigate to the server folder in a terminal, run 'npm i' then 'npm start'.

3. Navigate to the client folder then the highSchoolSite folder in a seperate terminal, run 'npm i' then 'ng serve --open'

The project should now be spun up locally on port 3000 for the server and port 4200 for the client.  If you would like to log in to the project, click on the copyright year in the footer and it will take you to the login page.  To log in, use these credentials:

user: eheeney

password: example1

Most of the functionality surrounding authorized users require that they click the picture of the faculty, news, or athlete that they want to update or delete.


# Features Implemented that Weren't Planned

Log In: We specified in our user stories authorized users can CRUD aspects of the site (like faculty or news) but neglected to include a user story which said someone could log into the system.  This allows regular users to become "authorized users"; authorized users take up a good part of the project's user stories so it was very important that we include this functionality.

Homepage: Another implemented feature that wasn't planned was a homepage.  All of the user stories that we listed pertained to their own, seperate pages; however, any website that is for public use (like ours) needs a homepage that people can navigate to and see the latest information of the school.

Error Handling: One aspect of a good website is it's ability to show users that something went wrong while getting, manipulating, or deleting data.  Since our backend threw errors such as 400 or 500, the user should also be able to see what exact error was being thrown, or at least be notified that a problem occured while getting a list of faculty or resources.

API Authorization: This goes hand in hand with the log in functionality.  Since we specified only authorized users should be able to change aspects of the website, our API needed to reflect that by including authorization.  This required changing some parts of front end http requests as well as registering the user's authorization in the backend.


# List of Completed User Stories

Bellow is a list of user stories with their corresponding issue numbers.

1. Homepage (#22)

2. Add, edit, or remove relevant events (#10)

3. Access list of student and parent resources (#8)

4. View relevant information and events occuring (#7)

5. Add and remove top performing athletes (#6)

6. Filter top performing athletes (#5)

7. See a list of top performing athletes (#4)

8. Add, edit, or remove faculty information (#3)

9. Filter list of faculty by department (#2)

10. See list of faculty (#1)

11. Add error handling to the front end (#27)

12. Add log in functionality (#16)

13. Add autorization for front end and back end (#30)

14. View school photos in the gallery (#9)
