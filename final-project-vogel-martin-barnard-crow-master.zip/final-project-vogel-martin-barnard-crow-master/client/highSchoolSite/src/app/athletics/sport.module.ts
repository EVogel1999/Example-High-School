import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SportComponent } from './sport.component';
import { SportCardComponent } from './sport-card/sport-card.component';

const appRoutes: Routes = [
  { path: '', component: SportComponent }
];

@NgModule({
  declarations: [SportComponent, SportCardComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(appRoutes)
  ]
})
export class SportModule { }