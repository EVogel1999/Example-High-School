import { Component, OnInit } from '@angular/core';
import {SportService} from '../services/sport.service';
import { AthletePopupComponent } from './athlete-popup/athlete-popup.component';
import { MatDialog } from '@angular/material';
import { SnackbarService } from '../services/snackbar.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'sport-page',
  templateUrl: './sport.component.html',
  styleUrls: [ './sport.component.css' ]
})

export class SportComponent implements OnInit  {

  sports: string[]=[];
  selectedSport: string[] = [];

athletes: {
  _id: string,
  name: string,
  sport: string[],
  description: string,
  picture: string,
  website?: string } []=[];

constructor(private sportService: SportService, private dialog: MatDialog, private snackbarService: SnackbarService,
  private authService: AuthService) { }

ngOnInit() {
  this.sportService.getAllSports().subscribe(myList => 
    {if (myList) {
    this.sports = myList;
  }
}, error => this.snackbarService.showMessage(error));

//Used To Retrieve Each And Every Athlete 
this.sportService.getAllAthletes().subscribe(myList => {
  if (myList) {
  this.athletes=myList;
  }
}, error => this.snackbarService.showMessage(error));
}

//Used To Filter The Athletes Shown By Their Sport
//If A Filter Is Chosen, Then The Athlete's Information 
//With That Chosen Sport Is Pushed To
//The selectedSport[] array For Display Purposes
filter(sp: string) {
  const isFound = this.selectedSport.find((sport: string) => {
    return sp === sport;
  });

  if (!isFound) {                   

    this.selectedSport.push(sp);

  } else {                        
    const myResult = [];

    this.selectedSport.forEach(spor => {
      if (sp !== spor) {
        myResult.push(spor);
      }
    });
    this.selectedSport = myResult;
  }

  if (this.selectedSport.length > 0) { 
    this.sportService.filterAthletes(this.selectedSport).subscribe(myList => {
      if (myList) {
        this.athletes = myList;
      }
    }, error => this.snackbarService.showMessage(error));
  } else {                       
    this.clearQuery();
  }
}

//Clears Any Filters That Are Currently In Place And
//Displays All Athletes
clearQuery() {
  this.selectedSport = [];

  this.sportService.getAllAthletes().subscribe(myList => {
    if (myList) {
      this.athletes = myList;
    }
  }, error => this.snackbarService.showMessage(error));
}

//Indicates Whether The selectedSport Array Has Any
//Values To Display
activated(sp: string): boolean {
  return -1 !== this.selectedSport.indexOf(sp);
}

/**
 * Register change in athlete list
 */
change() {
  this.sportService.getAllSports().toPromise().then(myList => {
    if (myList) {
      this.sports = myList;
    }
  }).catch(error => this.snackbarService.showMessage(error));
  this.clearQuery();
}

/**
 * Enables the create popup menu for a athlete
 */
addAthlete() {
  if (this.authService.user) {
    const dialogRef = this.dialog.open(AthletePopupComponent, { data: { mode: 'create' }});
    dialogRef.afterClosed().toPromise().then(() => {
      this.change();
    });
  } else {
    this.snackbarService.showMessage(new Error('You are not logged in'));
  }
}

}
