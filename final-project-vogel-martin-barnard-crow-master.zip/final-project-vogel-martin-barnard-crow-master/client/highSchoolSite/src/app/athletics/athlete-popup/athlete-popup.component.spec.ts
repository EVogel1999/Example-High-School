import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AthletePopupComponent } from './athlete-popup.component';

describe('AthletePopupComponent', () => {
  let component: AthletePopupComponent;
  let fixture: ComponentFixture<AthletePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AthletePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AthletePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
