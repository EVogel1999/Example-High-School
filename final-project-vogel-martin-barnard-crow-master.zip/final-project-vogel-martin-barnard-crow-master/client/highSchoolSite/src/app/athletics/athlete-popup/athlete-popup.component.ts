import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { SportService } from '../../services/sport.service';
import { SnackbarService } from 'src/app/services/snackbar.service';

@Component({
  selector: 'app-athlete-popup',
  templateUrl: './athlete-popup.component.html',
  styleUrls: ['./athlete-popup.component.css']
})
export class AthletePopupComponent implements OnInit {

  mode: string = '';
  model: {
    _id: string,
    name: string,
    sport: string[],
    description: string,
    picture: string,
    website?: string
  } = {
    _id: '',
    name: '',
    sport: [],
    description: '',
    picture: '',
    website: ''
  };
  arrayModel: {
    sport: string
  } = {
    sport: ''
  };
  sport: string[] = [];

  constructor(private dialogRef: MatDialogRef<AthletePopupComponent>, private sportService: SportService,
    private snackbarService: SnackbarService, @Inject(MAT_DIALOG_DATA) data) {
      this.mode = data.mode;
      if (data.mode === 'update') {
        this.model = data.model;
        this.sport = data.model.sport;
      }
    }

  ngOnInit() {
  }

  addSport() {
    this.sport.push(this.arrayModel.sport);
    this.arrayModel.sport = '';
  }

  removeSport(s: string) {
    const result: string[] = [];
    this.sport.forEach(val => {
      if (val !== s) {
        result.push(val);
      }
    });
    this.sport = result;
  }

  cancel() {
    this.dialogRef.close();
  }

  async finish() {
    try {
      if (this.mode === 'create') {
        const athlete = {
          name: this.model.name,
          sport: this.sport,
          description: this.model.description,
          picture: this.model.picture,
          website: this.model.website
        };
        await this.sportService.createAthlete(athlete);
      }
      if (this.mode === 'update') {
        await this.sportService.deleteAthelete(this.model._id);
      }
      this.cancel();
    } catch (error) {
      this.snackbarService.showMessage(error);
      this.cancel();
    }
  }

}
