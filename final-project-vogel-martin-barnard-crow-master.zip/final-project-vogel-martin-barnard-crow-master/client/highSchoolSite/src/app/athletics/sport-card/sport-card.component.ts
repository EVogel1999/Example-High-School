import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AthletePopupComponent } from '../athlete-popup/athlete-popup.component';
import { MatDialog } from '@angular/material';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-sport-card',
  templateUrl: './sport-card.component.html',
  styleUrls: ['./sport-card.component.css']
})
export class SportCardComponent implements OnInit {

  //Receives Input From The Parent Class, Which Is SportComponent
  @Input() athletes: {   
        _id: string,
        name: string,
        sport: string[],
        description: string,
        picture: string,
        website?: string };
  @Output() change: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(private dialog: MatDialog, private authService: AuthService) { }

  ngOnInit() { 
  }

  delete() {
    if (this.authService.user) {
      const model = JSON.parse(JSON.stringify(this.athletes));
      const dialogRef = this.dialog.open(AthletePopupComponent, { data: { mode: 'update', model: model }});
      dialogRef.afterClosed().toPromise().then(() => {
        this.change.emit(true);
      });
    }
  }

}
