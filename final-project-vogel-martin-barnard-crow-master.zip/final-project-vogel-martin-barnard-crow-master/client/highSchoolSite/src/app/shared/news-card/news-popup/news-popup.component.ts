import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { InfoServiceService } from 'src/app/services/info-service.service';
import { SnackbarService } from 'src/app/services/snackbar.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-news-popup',
  templateUrl: './news-popup.component.html',
  styleUrls: ['./news-popup.component.css']
})
export class NewsPopupComponent implements OnInit {

  toggle: boolean = false;
  mode: string;
  news: {
    _id: string,
    title: string,
    date: string,
    description: string,
    image: string,
    body: string
  };
  model: {
    _id: string,
    title: string,
    date: string,
    description: string,
    image: string,
    body: string
  } = {
    _id: '',
    title: '',
    date: '',
    description: '',
    image: '',
    body: ''
  };

  constructor(private dialogRef: MatDialogRef<NewsPopupComponent>, private infoService: InfoServiceService,
    private snackbarService: SnackbarService, private authService: AuthService, @Inject(MAT_DIALOG_DATA) data) {
      this.mode = data.mode;
      if (this.mode === 'create') {
        this.toggleEditCreate();
      }
      if (this.mode === 'update') {
        this.news = data.news;
        this.model = data.news;
      }
  }

  ngOnInit() {
  }

  toggleEditCreate() {
    if (this.authService.user)
      this.toggle = !this.toggle;
  }

  close() {
    this.dialogRef.close();
  }

  async delete() {
    if (this.authService.user) {
      try {
        if (this.mode === 'update') {
          await this.infoService.deleteNews(this.model._id);
        } else {
          throw new Error('You cannot delete news that doesn\'t exist');
        }
        this.close();
      } catch (error) {
        this.snackbarService.showMessage(error);
        this.close();
      }
    } else {
      this.snackbarService.showMessage(new Error('You must be logged in'));
    }
  }

  async finish() {
    if (this.authService.user) {
      try {
        const params = {
          title: this.model.title,
          date: this.model.date,
          description: this.model.description,
          link: this.model.image,
          body: this.model.body
        };
        if (this.mode === 'update') {
          await this.infoService.updateNews(this.news._id, params);
        }
        if (this.mode === 'create') {
          await this.infoService.createNews(params);
        }
        this.close();
      } catch (error) {
        this.snackbarService.showMessage(error);
        this.close();
      }
    } else {
      this.snackbarService.showMessage(new Error('You must be logged in'));
    }
  }

}
