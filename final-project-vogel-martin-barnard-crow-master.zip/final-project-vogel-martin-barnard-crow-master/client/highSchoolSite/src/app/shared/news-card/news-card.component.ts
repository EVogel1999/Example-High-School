import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material';
import { NewsPopupComponent } from './news-popup/news-popup.component';
import { AuthService } from 'src/app/services/auth.service';
import { SnackbarService } from 'src/app/services/snackbar.service';

@Component({
  selector: 'app-news-card',
  templateUrl: './news-card.component.html',
  styleUrls: ['./news-card.component.css']
})
export class NewsCardComponent implements OnInit {

  @Output() change: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Input() news: {
    _id: string,
    title: string,
    date: string,
    description: string,
    image: string,
    body: string
  };
  description: string;
  body: string;

  constructor(private dialog: MatDialog) { }

  ngOnInit() {
    this.description = this.news.description.substring(0, 80);
    this.body = this.news.body.substring(0, 130);
  }

  seeMore() {
    const dialogRef = this.dialog.open(NewsPopupComponent, { data: { mode: 'update', news: this.news }});
    dialogRef.afterClosed().toPromise().then(() => {
      this.change.emit(true);
    });
  }

}
