import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-homebox',
  templateUrl: './homebox.component.html',
  styleUrls: ['./homebox.component.css']
})
export class HomeboxComponent implements OnInit {
  @Input() news;
  @Input() event;
  
  constructor() { }

  ngOnInit() {
    
  }

}
