import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeboxComponent } from './homebox.component';

describe('HomeboxComponent', () => {
  let component: HomeboxComponent;
  let fixture: ComponentFixture<HomeboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
