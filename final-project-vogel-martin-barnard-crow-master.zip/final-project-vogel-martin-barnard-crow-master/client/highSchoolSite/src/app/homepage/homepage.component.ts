import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material';
import { HomepageService } from '../services/homepage.service';
import { NewsPopupComponent } from '../shared/news-card/news-popup/news-popup.component';
import { NewsCardComponent } from '../shared/news-card/news-card.component';
import { ResourcesService } from '../services/resources.service';
import { SnackbarService } from '../services/snackbar.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  news;
  event; 
 
  constructor(private Service: HomepageService,private dialog: MatDialog, private snackbarService: SnackbarService) { }

  ngOnInit() {
    this.getNews();

    this.Service.getSomeEvents().subscribe(list => {
      if (list) {
        this.event = list;
      }
    }, error => this.snackbarService.showMessage(error));
  }

  seeMore(card) {
    const dialogRef = this.dialog.open(NewsPopupComponent, { data: { mode: 'update', news: card }});
    dialogRef.afterClosed().toPromise().then(() => {
      this.getNews();
    });
  }

  seeEvent(card) {
    const dialogRef = this.dialog.open(NewsPopupComponent, { data: { mode: 'update', news: card }});
    dialogRef.afterClosed().toPromise().then(() => {
      this.getNews();
    });
  }

  getNews() {
    this.Service.getSomeNews().subscribe(list => {
      if (list) {
        this.news = list;
      }
    }, error => this.snackbarService.showMessage(error));
  }
}
