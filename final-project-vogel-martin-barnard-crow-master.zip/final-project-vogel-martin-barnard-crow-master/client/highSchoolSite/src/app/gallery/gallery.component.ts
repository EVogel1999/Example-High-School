import { GalleryService } from './../services/gallery.service';
import { Component, ChangeDetectionStrategy, OnInit } from '@angular/core';
import { Gallery, GalleryItem, ImageItem, ThumbnailsPosition, ImageSize } from '@ngx-gallery/core';
import { Lightbox } from '@ngx-gallery/lightbox';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {

  data;
  items: GalleryItem[] = [];
  imageData;

  constructor(public gallery: Gallery, public lightbox: Lightbox, private galService: GalleryService) {
  }
  
  ngOnInit() {
    this.galService.getAllPhotos().subscribe(photos => {
      if (photos) {
        console.log(photos);
        this.imageData = photos;
        this.getPhotos();
      }
    });
  }

  getPhotos() {
    console.log(this.imageData);
    this.items = this.imageData.map(item => new ImageItem({ src: item.srcUrl, thumb: item.previewUrl }));

    const lightboxRef = this.gallery.ref('lightbox');

    lightboxRef.setConfig({
      imageSize: ImageSize.Cover,
      thumbPosition: ThumbnailsPosition.Top
    });

    // Load items into the lightbox gallery ref
    lightboxRef.load(this.items);
  }

}
