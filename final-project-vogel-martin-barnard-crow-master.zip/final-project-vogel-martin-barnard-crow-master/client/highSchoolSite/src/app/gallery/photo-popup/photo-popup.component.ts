import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photo-popup',
  templateUrl: './photo-popup.component.html',
  styleUrls: ['./photo-popup.component.css']
})
export class PhotoPopupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
