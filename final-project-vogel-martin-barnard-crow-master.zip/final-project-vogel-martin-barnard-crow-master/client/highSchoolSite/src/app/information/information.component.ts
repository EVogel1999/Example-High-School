import { Component, OnInit, Input } from '@angular/core';
import { InfoServiceService } from '../services/info-service.service';
import { NewsPopupComponent } from '../shared/news-card/news-popup/news-popup.component';
import { MatDialog } from '@angular/material';
import { SnackbarService } from '../services/snackbar.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-information',
  templateUrl: './information.component.html',
  styleUrls: ['./information.component.css']
})
export class InformationComponent implements OnInit {

  @Input() news;

 
  constructor(private Service: InfoServiceService, private dialog: MatDialog, private snackbarService: SnackbarService,
    private authService: AuthService) { }

  ngOnInit() {
    this.getAllNews();
  }

  createNews() {
    if (this.authService.user) {
      const dialogRef = this.dialog.open(NewsPopupComponent, { data: { mode: 'create' }});
      dialogRef.afterClosed().toPromise().then(() => {
        this.getAllNews();
      });
    } else {
      this.snackbarService.showMessage(new Error('You are not logged in'));
    }
  }

  handelChange() {
    this.getAllNews();
  }

  getAllNews() {
    this.Service.getAllNews().subscribe(list => {
      if (list) {
        this.news = list;
      }
    }, error => this.snackbarService.showMessage(error));
  }
}
