import { User } from './../../user';
import { AuthService } from './../../services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { OnInit, Component } from '@angular/core';
import { SnackbarService } from 'src/app/services/snackbar.service';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {

  public user: User = {
    _id: 0,
    username: '',
    name: 'samplename',
    password: '',
    email: 'sampleemail',
    token: ''
  };
  constructor(private authService: AuthService, private router: Router, private snackbarService: SnackbarService) { }

  ngOnInit() {
  }

  validateLogin() {
    if (this.user.username && this.user.password) {
        this.authService.login(this.user.username, this.user.password).subscribe(result => {
        this.router.navigateByUrl('');
      }, error => this.snackbarService.showMessage(error));
    } else {
        alert('enter username and password');
    }
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['']);
  }

}
