import { Component, OnInit } from '@angular/core';
import {EventService} from '../services/events.service';
import { SnackbarService } from '../services/snackbar.service';

@Component({
  selector: 'event-page',
  templateUrl: './events.component.html',
  styleUrls: [ './events.component.css' ]
})

export class EventComponent implements OnInit  {

  event: {
    _id: string,
    name: string,
    date: string,
    description: string,
    picture: string,
    website?: string
} []=[];

constructor(private eventService: EventService, private snackbarService: SnackbarService) { }

ngOnInit() 
{
  this.eventService.getAllEvents().toPromise().then(val => {
    if (val) {
      this.event = val;
    }
  }).catch(error => this.snackbarService.showMessage(error));
}

}

