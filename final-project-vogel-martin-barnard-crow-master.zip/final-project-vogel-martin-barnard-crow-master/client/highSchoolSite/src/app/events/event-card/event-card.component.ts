import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-event-card',
  templateUrl: './event-card.component.html',
  styleUrls: ['./event-card.component.css']
})
export class EventCardComponent implements OnInit {

  @Input() event: {
    _id: string,
    name: string,
    date: string,
    description: string,
    picture: string,
    website?: string
  }

  constructor() { }

  ngOnInit() {
    
  }
}
