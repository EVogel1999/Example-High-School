import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule, MatSnackBarModule } from '@angular/material';
import { AppRoutingModule } from './app.routing.module';
import { EventComponent } from './events/events.component';
import { AppComponent } from './app.component';
import { NavbarComponent } from './shared/navbar/navbar.component';
import { FooterComponent } from './shared/footer/footer.component';
import { ResourcesComponent } from './resources/resources.component';
import { InformationComponent } from './information/information.component';
import { LogInComponent } from './logIn/log-in/log-in.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FacultyPopupComponent } from './faculty/shared/faculty-popup/faculty-popup.component';
import { AthletePopupComponent } from './athletics/athlete-popup/athlete-popup.component';
import { HomepageComponent } from './homepage/homepage.component';
import { HomeboxComponent } from './homepage/homebox/homebox.component';
import { NewsCardComponent } from './shared/news-card/news-card.component';
import { NewsPopupComponent } from './shared/news-card/news-popup/news-popup.component';
import { SportService } from './services/sport.service';
import { EventService } from './services/events.service';
import { EventCardComponent } from './events/event-card/event-card.component';
import { ResourceCardComponent } from './resources/resource-card/resource-card.component';
import { GalleryComponent } from './gallery/gallery.component';
import { NgxGalleryModule } from 'ngx-gallery';

import { GalleryModule } from '@ngx-gallery/core';
import { LightboxModule } from '@ngx-gallery/lightbox';
import { GallerizeModule } from '@ngx-gallery/gallerize';
import { PhotoPopupComponent } from './gallery/photo-popup/photo-popup.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    ResourcesComponent,
    InformationComponent,
    LogInComponent,
    FacultyPopupComponent,
    NewsCardComponent,
    NewsPopupComponent,
    EventComponent,
    EventCardComponent,
    ResourceCardComponent,
    HomepageComponent,
    HomeboxComponent,
    AthletePopupComponent,
    GalleryComponent,
    PhotoPopupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule,
    MatSnackBarModule,
    NgxGalleryModule,
    GalleryModule,
    LightboxModule,
    GallerizeModule
  ],

  providers: [SportService, EventService,
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    FacultyPopupComponent,
    NewsPopupComponent,
    AthletePopupComponent
  ]
})
export class AppModule { }
