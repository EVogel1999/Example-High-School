import { GalleryComponent } from './gallery/gallery.component';
import { LogInComponent } from './logIn/log-in/log-in.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ResourcesComponent } from './resources/resources.component';
import { InformationComponent } from './information/information.component';
import { HomepageComponent } from './homepage/homepage.component';
import {EventComponent} from './events/events.component';


const routes: Routes = [
  { path: 'faculty', loadChildren: './faculty/faculty.module#FacultyModule' },
  { path: 'resources', component: ResourcesComponent},
  { path: 'information', component: InformationComponent},
  { path: 'login', component: LogInComponent},
  { path: 'news', component: InformationComponent},
  { path: '', component: HomepageComponent},
  { path: 'athletes', loadChildren: './athletics/sport.module#SportModule'},
  { path: 'events', component: EventComponent},
  { path: 'gallery', component: GalleryComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }