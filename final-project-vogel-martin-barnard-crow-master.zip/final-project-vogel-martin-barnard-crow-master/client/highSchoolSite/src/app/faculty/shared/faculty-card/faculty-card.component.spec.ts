import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FacultyCardComponent } from './faculty-card.component';

describe('FacultyCardComponent', () => {
  let component: FacultyCardComponent;
  let fixture: ComponentFixture<FacultyCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FacultyCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FacultyCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
