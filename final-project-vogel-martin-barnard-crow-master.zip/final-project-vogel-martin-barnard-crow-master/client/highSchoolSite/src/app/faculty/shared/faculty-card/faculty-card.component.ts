import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FacultyPopupComponent } from '../faculty-popup/faculty-popup.component';
import { MatDialog } from "@angular/material";
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-faculty-card',
  templateUrl: './faculty-card.component.html',
  styleUrls: ['./faculty-card.component.css']
})
export class FacultyCardComponent implements OnInit {

  @Input() faculty: {   // The faculty to display on the card
    _id: string,
    name: string,
    role: string,
    email: string,
    classes: string[],
    department: string[],
    picture: string,
    website?: string
  };

  // Event emitter that emits when a change has been created in faculty
  @Output() change: EventEmitter<boolean> = new EventEmitter();

  classes: string;      // List of classes the faculty teaches

  /**
   * Constructor for faculty card
   * @param dialog Instance of angular material dialog
   */
  constructor(private dialog: MatDialog, private authService: AuthService) { }

  ngOnInit() {
    // Joins the faculty's classes together into one string to display
    this.classes = this.faculty.classes.join(', ');
  }

  /**
   * Opens the faculty popup component in dialog under update mode, on
   * close it emits the change output
   */
  update() {
    if (this.authService.user) {
      const copy = JSON.parse(JSON.stringify(this.faculty));
      const dialogRef = this.dialog.open(FacultyPopupComponent, {
        data: {
          faculty: copy,
          mode: 'update'
        }
      });
      dialogRef.afterClosed().toPromise().then(() => {
        this.change.emit(true);
      });
    }
  }

}
