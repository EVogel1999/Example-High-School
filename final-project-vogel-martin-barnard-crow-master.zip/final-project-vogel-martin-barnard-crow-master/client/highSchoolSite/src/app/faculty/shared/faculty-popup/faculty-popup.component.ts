import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { FacultyService } from 'src/app/services/faculty.service';
import { SnackbarService } from 'src/app/services/snackbar.service';

@Component({
  selector: 'app-faculty-popup',
  templateUrl: './faculty-popup.component.html',
  styleUrls: ['./faculty-popup.component.css']
})
export class FacultyPopupComponent implements OnInit {

  mode: string = '';            // Records the mode 'create' or 'update'
  page: number = 1;             // Records the page number of the form | 1 or 2
  model: {                      // Records the changes to an existing or new faculty
    _id: string,
    name: string,
    role: string,
    email: string,
    picture: string,
    website?: string
  } = {
    _id: '',
    name: '',
    role: '',
    email: '',
    picture: '',
    website: ''
  }
  arrayModel: {                 // Holds temporary class or department data for existing or new faculty
    class: string,
    department: string
  } = { 
    class: '',
    department: ''
  }
  classes: string[] = [];       // Holds the classes the faculty teaches
  departments: string[] = [];   // Holds the departments the faculty is part of

  /**
   * Sets the popup mode and gets the faculty data if applicable
   * @param dialogRef Dialog reference of the current popup
   * @param facultyService Instance of the faculty service
   * @param data Faculty data, only in update mode
   */
  constructor(private dialogRef: MatDialogRef<FacultyPopupComponent>, private facultyService: FacultyService,
    private snackbarService: SnackbarService, @Inject(MAT_DIALOG_DATA) data) {
      this.mode = data.mode;
      if (data.mode === 'update') {
        this.model = {
          _id: data.faculty._id,
          name: data.faculty.name,
          role: data.faculty.role,
          email: data.faculty.email,
          picture: data.faculty.picture,
          website: data.faculty.website
        };
        this.classes = data.faculty.classes;
        this.departments = data.faculty.department;
      }
    }

  ngOnInit() {
  }

  /**
   * Adds class to the class array and sets the model back to default
   */
  addClass() {
    this.classes.push(this.arrayModel.class);
    this.arrayModel.class = '';
  }

  /**
   * Removes a class from the class array
   * @param c Class to remove
   */
  removeClass(c: string) {
    const result: string[] = [];
    this.classes.forEach(val => {
      if (val !== c) {
        result.push(val);
      }
    });
    this.classes = result;
  }

  /**
   * Adds department to the department array and sets the model back to default
   */
  addDepartment() {
    this.departments.push(this.arrayModel.department);
    this.arrayModel.department = '';
  }

  /**
   * Removes a department from the department array
   * @param d Department to remove
   */
  removeDepartment(d: string) {
    const result: string[] = [];
    this.departments.forEach(val => {
      if (val !== d) {
        result.push(val);
      }
    });
    this.departments = result;
  }

  /**
   * Closes the dialog
   */
  cancel() {
    this.dialogRef.close();
  }

  /**
   * Navigates the user back a page
   */
  back() {
    this.page = 1;
  }

  /**
   * Navigates the user forward a page
   */
  next() {
    this.page = 2;
  }

  /**
   * Deletes faculty from database and closes the dialog
   */
  async delete() {
    try {
      if (this.mode === 'update') {
        await this.facultyService.fireFaculty(this.model._id);
      } else {
        throw new Error('You cannot delete a faculty that doesn\'t exist');
      }
    } catch (error) {
      this.snackbarService.showMessage(error);
    }
    this.dialogRef.close();
  }

  /**
   * Updates or creates the faculty in the database then closes the dialog
   */
  async finish() {
    const faculty = {
      _id: this.model._id,
      name: this.model.name,
      email: this.model.email,
      role: this.model.role,
      picture: this.model.picture,
      website: this.model.website,
      classes: this.classes,
      department: this.departments
    };
    try {
      if (this.mode === 'create') {
        await this.facultyService.hireFaculty(faculty);
      }
      if (this.mode === 'update') {
        await this.facultyService.updateFaculty(faculty);
      }
    } catch (error) {
      this.snackbarService.showMessage(error);
    }
    this.dialogRef.close();
  }

}
