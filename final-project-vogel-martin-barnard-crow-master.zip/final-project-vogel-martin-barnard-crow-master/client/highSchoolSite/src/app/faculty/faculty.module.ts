import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { FacultyComponent } from './faculty.component';
import { FacultyCardComponent } from './shared/faculty-card/faculty-card.component';

const appRoutes: Routes = [
  { path: '', component: FacultyComponent }
];

@NgModule({
  declarations: [FacultyComponent, FacultyCardComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(appRoutes)
  ]
})
export class FacultyModule { }
