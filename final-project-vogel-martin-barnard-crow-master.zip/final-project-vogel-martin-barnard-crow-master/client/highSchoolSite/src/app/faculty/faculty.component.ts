import { Component, OnInit } from '@angular/core';
import { FacultyService } from '../services/faculty.service';
import { FacultyPopupComponent } from './shared/faculty-popup/faculty-popup.component';
import { MatDialog } from '@angular/material';
import { SnackbarService } from '../services/snackbar.service';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-faculty',
  templateUrl: './faculty.component.html',
  styleUrls: ['./faculty.component.css']
})
export class FacultyComponent implements OnInit {

  // Filtering arrays
  departments: string[] = [];
  selected: string[] = [];

  // Faculty list, filtered or not
  faculty: {
    _id: string,
    name: string,
    role: string,
    email: string,
    classes: string[],
    department: string[],
    picture: string,
    website?: string}[] = [];

  /**
   * Constructor method of the faculty component
   * @param facultyService Instance of the faculty service
   * @param dialog Instance of the dialog component from angular material
   */
  constructor(private facultyService: FacultyService, private dialog: MatDialog, private snackbarService: SnackbarService,
    private authService: AuthService) { }

  /**
   * Get's the list of departments and unfiltered faculty list
   */
  ngOnInit() {
    // Gets departments
    this.getListOfDepartments();

    // Gets all faculty
    this.clearQuery();
  }

  /**
   * Filter's faculty by a list of departments
   * @param d Department selected
   */
  filter(d: string) {
    // Try to find if the department is already selected
    const found = this.selected.find((department: string) => {
      return d === department;
    });

    if (!found) {                   // If it isn't then push it into selected
      this.selected.push(d);
    } else {                        // Else remove it from the selected list
      const result = [];
      this.selected.forEach(dep => {
        if (d !== dep) {
          result.push(dep);
        }
      });
      this.selected = result;
    }

    if (this.selected.length > 0) { // If there is a request to filter, get the filtered faculty
      this.facultyService.filterFaculty(this.selected).toPromise().then(list => {
        if (list) {
          this.faculty = list;
        }
      }).catch(error => this.snackbarService.showMessage(error));
    } else {                        // If there isn't any selected then clear the query
      this.clearQuery();
    }
  }

  /**
   * Clears the query by removing the selected departments and getting the full list of faculty
   */
  clearQuery() {
    this.selected = [];
    this.facultyService.getAllFaculty().toPromise().then(list => {
      if (list) {
        this.faculty = list;
      }
    }).catch(error => this.snackbarService.showMessage(error));
  }

  /**
   * Retrieves list of departments
   */
  getListOfDepartments() {
    this.facultyService.getDepartments().toPromise().then(list => {
      if (list) {
        this.departments = list;
      }
    }).catch(error => this.snackbarService.showMessage(error));
  }

  /**
   * Checks if the department is selected to display the filter button shaded
   * @param d Department string
   */
  activated(d: string): boolean {
    return -1 !== this.selected.indexOf(d);
  }

  /**
   * Registers that there is a change in faculty information and automatically gets
   * the faculty information and reupdates the list of departments
   */
  change() {
    this.getListOfDepartments();
    this.clearQuery();
  }

  /**
   * Opens the faculty popup dialog in create mode, on close it calls the change method
   */
  addFaculty() {
    if (this.authService.user) {
      const dialogRef = this.dialog.open(FacultyPopupComponent, { data: { mode: 'create' }});
      dialogRef.afterClosed().toPromise().then(() => {
        this.change();
      });
    } else {
      this.snackbarService.showMessage(new Error('You are not logged in'));
    }
  }

}
