import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GalleryService {

  constructor(private http: HttpClient) { }

  getAllPhotos() {
    return this.http.get<{
      _id: string,
      srcUrl: string,
      previewUrl: string}[]>
      ('http://localhost:3000/photos');
  }
}
