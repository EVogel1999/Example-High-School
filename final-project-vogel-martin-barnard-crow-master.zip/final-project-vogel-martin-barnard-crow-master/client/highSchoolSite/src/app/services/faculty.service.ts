import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class FacultyService {

  constructor(private http: HttpClient, private authService: AuthService) { }

  getAllFaculty() {
    return this.http.get<{
      _id: string,
      name: string,
      role: string,
      email: string,
      classes: string[],
      department: string[],
      picture: string,
      website?: string}[]>
      ('http://localhost:3000/faculty');
  }

  filterFaculty(departments: string[]) {
    const filter = '\"' + departments.join('\",\"') + '\"';
    return this.http.get<{
      _id: string,
      name: string,
      role: string,
      email: string,
      classes: string[],
      department: string[],
      picture: string,
      website?: string}[]>('http://localhost:3000/faculty?departments=['+filter+']');
  }

  getDepartments() {
    return this.http.get<string[]>('http://localhost:3000/departments');
  }

  hireFaculty(faculty: {
    _id: string,
    name: string,
    role: string,
    email: string,
    classes: string[],
    department: string[],
    picture: string,
    website?: string,}) {
      if (faculty.website && faculty.website.length > 0) {
        return this.http.post('http://localhost:3000/faculty', {
          name: faculty.name,
          role: faculty.role,
          email: faculty.email,
          classes: faculty.classes,
          department: faculty.department,
          picture: faculty.picture,
          website: faculty.website
        }, { responseType: "text", headers: new HttpHeaders().set('authorization', this.authService.user.token) }).toPromise();
      } else {
        return this.http.post('http://localhost:3000/faculty', {
          name: faculty.name,
          role: faculty.role,
          email: faculty.email,
          classes: faculty.classes,
          department: faculty.department,
          picture: faculty.picture
        }, { responseType: "text", headers: new HttpHeaders().set('authorization', this.authService.user.token) }).toPromise();
      }
  }

  updateFaculty(faculty: {
    _id: string,
    name: string,
    role: string,
    email: string,
    classes: string[],
    department: string[],
    picture: string,
    website?: string,}) {
      if (faculty.website && faculty.website.length > 0) {
        return this.http.patch('http://localhost:3000/faculty/'+faculty._id, {
          name: faculty.name,
          role: faculty.role,
          email: faculty.email,
          classes: faculty.classes,
          department: faculty.department,
          picture: faculty.picture,
          website: faculty.website
        }, { headers: new HttpHeaders().set('authorization', this.authService.user.token) }).toPromise();
      } else {
        return this.http.patch('http://localhost:3000/faculty/'+faculty._id, {
          name: faculty.name,
          role: faculty.role,
          email: faculty.email,
          classes: faculty.classes,
          department: faculty.department,
          picture: faculty.picture
        }, { headers: new HttpHeaders().set('authorization', this.authService.user.token) }).toPromise();
      }
  }

  fireFaculty(id: string) {
    return this.http.delete('http://localhost:3000/faculty/'+id,
    { headers: new HttpHeaders().set('authorization', this.authService.user.token) }).toPromise();
  }
}
