import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class SportService {

  constructor(private http: HttpClient, private authService: AuthService) { }

  getAllAthletes() {
    return this.http.get<{
      _id: string,
      name: string,
      sport: string[],
      description: string,
      picture: string,
      website?: string,}[]>
      ('http://localhost:3000/athletes');
  }
  
  filterAthletes(sports: string[]) {
    const filter = '\"' + sports.join('\",\"') + '\"';
    return this.http.get<{
        _id: string,
        name: string,
        sport: string[],
        description: string,
        picture: string,
        website?: string,}[]>('http://localhost:3000/athletes?sports=['+filter+"]");
  }

  getAllSports(){
    return this.http.get<string[]>('http://localhost:3000/sports'); 
  }

  createAthlete(params: {name: string, sport: string[], description: string, picture: string, website?: string}) {
    return this.http.post('http://localhost:3000/athletes', {
      name: params.name,
      sport: params.sport,
      description: params.description,
      picture: params.picture,
      website: params.website
    }, { responseType: 'text', headers: new HttpHeaders().set('authorization', this.authService.user.token) }).toPromise();
  }

  deleteAthelete(id: string) {
    return this.http.delete('http://localhost:3000/athletes/'+ id,
    { headers: new HttpHeaders().set('authorization', this.authService.user.token) }).toPromise();
  }
}
