import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HomepageService {

  constructor(private http: HttpClient) {}
  
  getSomeNews() {
    return this.http.get<{
      _id: string,
      title: string;
    }>('http://localhost:3000/News');

  }

  getSomeEvents(){
    return this.http.get<{
      _id: string,
      name: string;
    }>('http://localhost:3000/events');
  }
}
