import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ResourcesService {

  constructor(private http: HttpClient) { }
  getAllResources() {
    return this.http.get<{
      _id: string,
      name: string,
      description: string,
      website?: string,}[]>
      ('http://localhost:3000/resources');
        } 
  }
