import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EventService {

  constructor(private http: HttpClient) { }

  getAllEvents() {
    return this.http.get<{
      _id: string,
      name: string,
      date: string,
      description: string,
      picture: string,
      website: string}[]>
      ('http://localhost:3000/events');
  }
}
