import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class InfoServiceService {

  constructor(private http: HttpClient, private authService: AuthService) { }

  getAllNews(){
    return this.http.get<{
      _id: string,
      title: string,
      description: string,
      date: string,
      body: string,
      link?: string}[]>
      ('http://localhost:3000/news');
  } 
  
  createNews(params: {
    title: string,
    description: string,
    date: string,
    body: string,
    link: string}) {
      return this.http.post('http://localhost:3000/news', {
        title: params.title,
        description: params.description,
        date: params.date,
        body: params.body,
        image: params.link
      },
      { responseType: 'text', headers: new HttpHeaders().set('authorization', this.authService.user.token) }).toPromise();
  }

  updateNews(id: string, params: {
    title: string,
    description: string,
    date: string,
    body: string,
    link: string}) {
      return this.http.patch('http://localhost:3000/news/'+id, {
        title: params.title,
        description: params.description,
        date: params.date,
        body: params.body,
        image: params.link
      }, { headers: new HttpHeaders().set('authorization', this.authService.user.token) }).toPromise();
  }

  deleteNews(id: string) {
    return this.http.delete('http://localhost:3000/news/'+id,
    { headers: new HttpHeaders().set('authorization', this.authService.user.token) }).toPromise();
  }
  
}