import { Injectable } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig } from "@angular/material";

@Injectable({
  providedIn: 'root'
})
export class SnackbarService {

  private config: MatSnackBarConfig<any>;

  constructor(private snackBar: MatSnackBar) {
    this.config = new MatSnackBarConfig();
    this.config.verticalPosition = 'bottom';
    this.config.horizontalPosition = 'left';
    this.config.duration = 4000;
  }

  showMessage(error) {
    console.error(error);
    let message = '';
    if (error.error) {
      message = error.error;
    } else {
      message = error.message;
    }
    this.snackBar.open(message, undefined, this.config);
  }
}
