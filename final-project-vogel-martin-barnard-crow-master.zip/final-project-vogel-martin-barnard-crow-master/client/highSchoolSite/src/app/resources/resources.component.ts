import { Component, OnInit } from '@angular/core';
import { ResourcesService } from '../services/resources.service';
import { SnackbarService } from '../services/snackbar.service';

@Component({
  selector: 'app-resources',
  templateUrl: './resources.component.html',
  styleUrls: ['./resources.component.css']
})
export class ResourcesComponent implements OnInit {
  resource:{
    _id:string,
    name:string,
    description:string,
    website?: string;}[] = []

  constructor(private service: ResourcesService, private snackbarService: SnackbarService) { }

  ngOnInit() {
    this.service.getAllResources().subscribe(list => {
      if(list)
      this.resource = list;
    }, error => this.snackbarService.showMessage(error));
  }

}
