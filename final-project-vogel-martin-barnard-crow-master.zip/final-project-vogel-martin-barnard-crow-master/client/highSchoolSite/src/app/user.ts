export interface User {
    _id: number;
    username: string;
    name: string;
    password: string;
    email: string;
    token?: string;
}
